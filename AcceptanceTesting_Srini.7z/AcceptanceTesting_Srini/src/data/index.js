/*Cities - data*/
import aberdeen from './aberdeen';
import dundee from './dundee';
import edinburgh from './edinburgh';
import glasgow from './glasgow';
import perth from './perth';
import stirling from './stirling';

export default {
  aberdeen
, dundee
, edinburgh
, glasgow
, perth
, stirling
};