import { expect } from 'chai'
import { mapForecast } from '../../../src/ducks/forecast'

describe('Forecast mapper', () => {
});